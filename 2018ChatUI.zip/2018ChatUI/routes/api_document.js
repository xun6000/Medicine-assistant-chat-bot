/**
 * Created by Jie on 2016/2/19.
 */
var express = require('express');
var router = express.Router();
var marked = require('marked');
var cache = require('./cache');
var path = require('path');
marked.setOptions({
    renderer: new marked.Renderer(),
    gfm: true,
    tables: true,
    breaks: false,
    pedantic: false,
    sanitize: true,
    smartLists: true,
    smartypants: false
});
var htmlstr;
fs = require('fs')
fs.readFile(path.join(__dirname, '../docs','api.md'), 'utf8', function (err,data) {
    if (err) {
        return console.log(err);
    }
    htmlstr = marked(data)
    cache.set("htmlstr",htmlstr,0);
});

/* GET home page. */
router.get('/', function(req, res, next) {

    res.render('markdown', { title: 'SME Support - API', htmlstr: cache.get("htmlstr") });
});

module.exports = router;
