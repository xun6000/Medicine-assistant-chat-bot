var express = require('express');
var router = express.Router();
var cache = require('./cache');

/* GET home page. */
router.get('/', function(req, res, next) {

    return res.render('index', { title: 'Home'});
});

module.exports = router;
