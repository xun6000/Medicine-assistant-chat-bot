var request = require('request');

// read the api.ai docs : https://api.ai/docs/



// Function which returns speech from api.ai
var getRes = function(query) {
    var data = {};
    data['text'] = query;
    data['information'] = [2, "12:00", "female", "young", "Ma", ["Tiago", "Tesco"]];

    console.log(data);

    var options = {
        uri: 'http://127.0.0.1:9099',
        method: 'POST',
        json: data
    };

    const responseFromAPI = new Promise(
        function (resolve, reject) {
            request(options,
                function (error, response, body) {
                    if (!error && response.statusCode == 200) {
                        //console.log(body);
                        resolve(body);
                    }else{
                        //console.log(body);
                        //resolve(body);
                        var res = {};
                        res['response'] = "[ERROR] Cannot Connect To The Server..."
                        resolve(res);
                    }
                }
            );
        });

    return responseFromAPI;
};

// test the command :
//getRes('hello').then(function(res){console.log(res)});

module.exports = {getRes}
