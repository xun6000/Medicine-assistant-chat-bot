The Reinforcement Learning depends on the following APIs.

## 1. Get Questions
### URL
* [/api/get/questions]()

### Method
POST

### Development status
* done

### Description
* To be added


### Input


```js
{
  "company": "SPX",
  "people": ["CTO", "CFO", "CIO", "Finance Director", "Global Process Owner", "SAP Process Manager"],
  "category": ["Order to Cash (OTC)"],
  "subcategory": ["Client Requests"]
}
```


### Output


```js
{
"status": 1,
"questions": [
  {
"question": "Do you have any requests?",
"score": 3
},
  {
"question": "Do you have any questions about S/4HANA?",
"score": 3
},
  {
"question": "Do you have questions about the capabilities of S/4HANA?",
"score": 3
}
],
}
```