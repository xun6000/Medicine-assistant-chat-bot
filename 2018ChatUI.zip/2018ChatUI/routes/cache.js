var NodeCache = require( "node-cache" );
var data = new NodeCache();
module.exports = data;
