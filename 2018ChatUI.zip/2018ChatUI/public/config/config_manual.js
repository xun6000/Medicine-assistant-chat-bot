$(document).ready(function() {
    $.getJSON("/api/vibration", function(result) {
        if (result["Vibration"]){
            $(VIBRATION_TRUE).prop("checked", true);
            $(VIBRATION_FALSE).prop("checked", false);
        }else{
            $(VIBRATION_TRUE).prop("checked", false);
            $(VIBRATION_FALSE).prop("checked", true);
        }
    });
    $.getJSON("/api/rpm", function(result) {
        if (result["Erratic"]){
            $(RPM_ERRATIC_TRUE).prop("checked", true);
            $(RPM_ERRATIC_FALSE).prop("checked", false);
        }else{
            $(RPM_ERRATIC_TRUE).prop("checked", false);
            $(RPM_ERRATIC_FALSE).prop("checked", true);
        }
        if (result["Drops_suddenly"]){
            $(RPM_DROPS_SUDDENLY_TRUE).prop("checked", true);
            $(RPM_DROPS_SUDDENLY_FALSE).prop("checked", false);
        }else{
            $(RPM_DROPS_SUDDENLY_TRUE).prop("checked", false);
            $(RPM_DROPS_SUDDENLY_FALSE).prop("checked", true);
        }
    });

    $.getJSON("/api/kinematics", function(result) {
        if (result["state"] == "Off"){
            $(KINEMATICS_OFF).prop("checked", true);
            $(KINEMATICS_IDLE).prop("checked", false);
            $(KINEMATICS_STEADYSPEED).prop("checked", false);
            $(KINEMATICS_ACCELERATION).prop("checked", false);
        }
        if (result["state"] == "Idle"){
            $(KINEMATICS_OFF).prop("checked", false);
            $(KINEMATICS_IDLE).prop("checked", true);
            $(KINEMATICS_STEADYSPEED).prop("checked", false);
            $(KINEMATICS_ACCELERATION).prop("checked", false);
        }
        if (result["state"] == "SteadySpeed"){
            $(KINEMATICS_OFF).prop("checked", false);
            $(KINEMATICS_IDLE).prop("checked", false);
            $(KINEMATICS_STEADYSPEED).prop("checked", true);
            $(KINEMATICS_ACCELERATION).prop("checked", false);
        }
        if (result["state"] == "Acceleration"){
            $(KINEMATICS_OFF).prop("checked", false);
            $(KINEMATICS_IDLE).prop("checked", false);
            $(KINEMATICS_STEADYSPEED).prop("checked", false);
            $(KINEMATICS_ACCELERATION).prop("checked", true);
        }
    });

    $('#VIBRATION_TRUE').click(function(){
        $.getJSON("/api/set/vibration?vibration=1", function(result) {});
    });
    $('#VIBRATION_FALSE').click(function(){
        $.getJSON("/api/set/vibration?vibration=0", function(result) {});
    });

    $('#RPM_ERRATIC_TRUE').click(function(){
        $.getJSON("/api/set/rpm?erratic=1", function(result) {});
    });
    $('#RPM_ERRATIC_FALSE').click(function(){
        $.getJSON("/api/set/rpm?erratic=0", function(result) {});
    });

    $('#RPM_DROPS_SUDDENLY_TRUE').click(function(){
        $.getJSON("/api/set/rpm?drops_suddenly=1", function(result) {});
    });
    $('#RPM_DROPS_SUDDENLY_FALSE').click(function(){
        $.getJSON("/api/set/rpm?drops_suddenly=0", function(result) {});
    });

    $('#KINEMATICS_OFF').click(function(){
        $.getJSON("/api/set/kinematics?state=0", function(result) {});
    });
    $('#KINEMATICS_IDLE').click(function(){
        $.getJSON("/api/set/kinematics?state=1", function(result) {});
    });
    $('#KINEMATICS_STEADYSPEED').click(function(){
        $.getJSON("/api/set/kinematics?state=2", function(result) {});
    });
    $('#KINEMATICS_ACCELERATION').click(function(){
        $.getJSON("/api/set/kinematics?state=3", function(result) {});
    });
});