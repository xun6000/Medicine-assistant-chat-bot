var app = require('express')();
var server = require('http').Server(app);
var io = require('socket.io')(server);

var api = require('./chatapi');

var conn = function() {
    server.listen(8001);

    app.get('/', function (req, res) {
        res.sendfile(__dirname + '/index.html');
    });
};

var fromClient = function() {

    io.on('connection', function (socket) {
        socket.on('fromClient', function (data) {
            console.log(data.client);
            //socket.emit('fromServer', { server: "test2" });
         api.getRes(data.client).then(function(res){
           console.log('response', res);
            socket.emit('fromServer', { server: res });
         });
        });
    });
}
module.exports = {conn,fromClient}
