var botui = new BotUI('api-bot');

var socket = io.connect('http://localhost:8001');
// read the BotUI docs : https://docs.botui.org/

$(document).ready(function(){
    console.log("value")
    $("#current_state").val("");
    $("#optimal_plan").val("");
    $("#number_of_people").val("2");
    $("#time").val("12:00");
    $("#name").val("Jery");
    $("#operator_gender").val("male");
    $("#operator_age").val("young");
    $("#status").val("1");

});
$( "#start" ).click(function() {

    socket.emit('fromClient', {client: "start"});
    socket.on('fromServer', function (data) { // recieveing a reply from server.
        console.log(data.server['response']);
        newMessage(data.server['response']);
        $("#current_state").val(data.server['intent']);
        // var plan_str = '';
        // data.server['plan'].forEach(function(element) {
        //     if (plan_str == ''){
        //         plan_str = plan_str+element;
        //     }else{
        //         plan_str = plan_str + "->" + element;
        //     }
        //
        // });
        $("#optimal_plan").val(data.server['medicine']);
        $("#DNN").val(data.server['DNN']);

        if (data.server['response']==="请输入您的问题" || "ERROR" in data.server['response']){

            $("#Rule-based").val("");

        }else{
            $("#Rule-based").val(data.server['response']);

        };



        addAction();
    })

});
botui.message.add({
    content: 'Welcome to Medical Helper Dashboard',
    delay: 1500,
})

function newMessage (response) {
    botui.message.add({
        content: response,
        delay: 0,
    })
}

function addAction () {
    botui.action.text({
        action: {
            placeholder: 'Input Your Response Here...',
        }
    }).then(function (res) {
        var status = $("#status").val();
        console.log(res.value+"___"+status)
        socket.emit('fromClient', { client : res.value+"___"+status });
        console.log('client response: ', res.value);
    })
}